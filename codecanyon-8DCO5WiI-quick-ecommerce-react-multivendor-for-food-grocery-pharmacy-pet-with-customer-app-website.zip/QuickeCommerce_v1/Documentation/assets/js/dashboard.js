// Dashboard JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Initialize dashboard
    loadSavedTheme();
    setupSearchFunctionality();
    setupCardAnimations();
});


// Theme Management
function toggleTheme() {
    const body = document.body;
    const themeIcon = document.querySelector('.theme-toggle i');
    
    body.classList.toggle('dark-theme');
    
    // Update icon
    if (body.classList.contains('dark-theme')) {
        themeIcon.className = 'fas fa-sun';
        localStorage.setItem('theme', 'dark');
    } else {
        themeIcon.className = 'fas fa-moon';
        localStorage.setItem('theme', 'light');
    }
    
    // Animate theme transition
    document.documentElement.style.transition = 'all 0.3s ease';
    setTimeout(() => {
        document.documentElement.style.transition = '';
    }, 300);
}

function loadSavedTheme() {
    const savedTheme = localStorage.getItem('theme');
    const body = document.body;
    const themeIcon = document.querySelector('.theme-toggle i');
    
    if (savedTheme === 'dark') {
        body.classList.add('dark-theme');
        themeIcon.className = 'fas fa-sun';
    } else {
        body.classList.remove('dark-theme');
        themeIcon.className = 'fas fa-moon';
    }
}

// Search Functionality
function setupSearchFunctionality() {
    const searchInput = document.getElementById('dashboard-search');
    if (!searchInput) return;
    
    // Add search event listeners
    searchInput.addEventListener('input', function() {
        const query = this.value.toLowerCase().trim();
        searchCards(query);
    });
    
    // Add search keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        if (e.ctrlKey && e.key === 'k') {
            e.preventDefault();
            searchInput.focus();
            searchInput.select();
        }
        
        if (e.key === 'Escape' && document.activeElement === searchInput) {
            searchInput.blur();
            searchInput.value = '';
            searchCards('');
        }
    });
}

function searchCards(query) {
    const cards = document.querySelectorAll('.doc-card');
    const cardsGrid = document.getElementById('cards-grid');
    let visibleCount = 0;
    
    cards.forEach(card => {
        const title = card.querySelector('.card-title').textContent.toLowerCase();
        const description = card.querySelector('.card-description').textContent.toLowerCase();
        const category = card.getAttribute('data-category').toLowerCase();
        const features = Array.from(card.querySelectorAll('.feature-tag')).map(tag => tag.textContent.toLowerCase()).join(' ');
        
        const searchText = `${title} ${description} ${category} ${features}`;
        const isMatch = searchText.includes(query);
        
        if (isMatch) {
            card.style.display = 'block';
            card.classList.add('search-match');
            visibleCount++;
            
            // Animate card appearance
            setTimeout(() => {
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, visibleCount * 50);
            
        } else {
            card.style.opacity = '0.3';
            card.style.transform = 'translateY(20px)';
            card.classList.remove('search-match');
            
            setTimeout(() => {
                if (!card.classList.contains('search-match')) {
                    card.style.display = 'none';
                }
            }, 300);
        }
    });
    
    // Show no results message
    showNoResultsMessage(visibleCount === 0 && query.length > 0);
}

function showNoResultsMessage(show) {
    const existingMessage = document.querySelector('.no-results');
    
    if (show) {
        if (!existingMessage) {
            const noResultsDiv = document.createElement('div');
            noResultsDiv.className = 'no-results';
            noResultsDiv.innerHTML = `
                <div class="no-results-content">
                    <i class="fas fa-search"></i>
                    <h3>No Results Found</h3>
                    <p>Try adjusting your search terms or browse all documentation below.</p>
                    <button class="btn-clear-search" onclick="clearSearch()">
                        <i class="fas fa-times"></i> Clear Search
                    </button>
                </div>
            `;
            document.getElementById('cards-grid').appendChild(noResultsDiv);
        }
    } else {
        if (existingMessage) {
            existingMessage.remove();
        }
    }
}

function clearSearch() {
    const searchInput = document.getElementById('dashboard-search');
    searchInput.value = '';
    searchCards('');
    searchInput.focus();
}

// Card Animation Setup
function setupCardAnimations() {
    const cards = document.querySelectorAll('.doc-card');

cards.forEach(card => {

    const cardIcon = card.querySelector('.card-icon');
    const cardArrow = card.querySelector('.card-arrow');

    card.addEventListener('mouseenter', () => {
        if (cardIcon) cardIcon.style.transform = 'scale(1.1) rotate(5deg)';
        if (cardArrow) cardArrow.style.transform = 'rotate(45deg) scale(1.2)';
    });

    card.addEventListener('mouseleave', () => {
        if (cardIcon) cardIcon.style.transform = 'scale(1) rotate(0deg)';
        if (cardArrow) cardArrow.style.transform = 'rotate(0deg) scale(1)';
    });

    // Add ripple effect on click
    card.addEventListener('click', function(e) {
        createRippleEffect(e, this);
    });
});

}

function createRippleEffect(e, element) {
    const ripple = document.createElement('div');
    const rect = element.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    const x = e.clientX - rect.left - size / 2;
    const y = e.clientY - rect.top - size / 2;
    
    ripple.className = 'ripple-effect';
    ripple.style.cssText = `
        position: absolute;
        width: ${size}px;
        height: ${size}px;
        left: ${x}px;
        top: ${y}px;
        background: rgba(102, 126, 234, 0.3);
        border-radius: 50%;
        transform: scale(0);
        animation: ripple 0.6s ease-out;
        pointer-events: none;
        z-index: 1;
    `;
    
    element.style.position = 'relative';
    element.style.overflow = 'hidden';
    element.appendChild(ripple);
    
    setTimeout(() => {
        ripple.remove();
    }, 600);
}

// Navigation to documentation
function openDocumentation(docType) {
    // Add loading state
    const card = event.currentTarget;
    const originalContent = card.innerHTML;
    
    card.classList.add('loading');
    
    // Simulate loading
    setTimeout(() => {
        // Navigate to documentation page
        window.location.href = `documentation.html?doc=${docType}`;
    }, 800);
}

// Intersection Observer for scroll animations
function setupIntersectionObserver() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    }, observerOptions);
    
    // Observe all cards and stats
    document.querySelectorAll('.doc-card, .stat-card').forEach(el => {
        observer.observe(el);
    });
}

// Utility Functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Add CSS for animations
const style = document.createElement('style');
style.textContent = `
    .fade-in-up {
        opacity: 0;
        transform: translateY(30px);
        animation: fadeInUp 0.8s ease-out forwards;
    }
    
    @keyframes fadeInUp {
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    @keyframes ripple {
        to {
            transform: scale(2);
            opacity: 0;
        }
    }
    
    .animate-in {
        animation: slideInUp 0.6s ease-out;
    }
    
    @keyframes slideInUp {
        from {
            opacity: 0;
            transform: translateY(50px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .loading {
        pointer-events: none;
        opacity: 0.7;
        transform: scale(0.98);
        transition: all 0.3s ease;
    }
    
    .loading::after {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        width: 40px;
        height: 40px;
        margin: -20px 0 0 -20px;
        border: 3px solid rgba(102, 126, 234, 0.3);
        border-top: 3px solid #667eea;
        border-radius: 50%;
        animation: spin 1s linear infinite;
    }
    
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
    
    .no-results {
        grid-column: 1 / -1;
        text-align: center;
        padding: 60px 20px;
        opacity: 0;
        animation: fadeIn 0.5s ease-out 0.3s forwards;
    }
    
    .no-results-content {
        max-width: 400px;
        margin: 0 auto;
    }
    
    .no-results i {
        font-size: 48px;
        color: var(--text-secondary);
        margin-bottom: 20px;
        opacity: 0.5;
    }
    
    .no-results h3 {
        font-size: 1.5rem;
        margin-bottom: 10px;
        color: var(--text-primary);
    }
    
    .no-results p {
        color: var(--text-secondary);
        margin-bottom: 30px;
    }
    
    .btn-clear-search {
        background: var(--primary-gradient);
        color: white;
        border: none;
        padding: 12px 24px;
        border-radius: 25px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s ease;
        display: inline-flex;
        align-items: center;
        gap: 8px;
    }
    
    .btn-clear-search:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 20px rgba(102, 126, 234, 0.3);
    }
    
    @keyframes fadeIn {
        to { opacity: 1; }
    }
    
    /* Search input enhancements */
    .search-input:focus + .search-suggestions {
        display: block;
    }
    
    .search-match {
        position: relative;
    }
    
    .search-match::before {
        transform: scaleX(1) !important;
    }
`;

document.head.appendChild(style);


// Add error handling
window.addEventListener('error', function(e) {
    console.error('Dashboard Error:', e.error);
});

// Add performance metrics
window.addEventListener('load', function() {
    const loadTime = performance.now();
    console.log(`Dashboard loaded in ${loadTime.toFixed(2)}ms`);
});