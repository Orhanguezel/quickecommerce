// Documentation JavaScript
document.addEventListener('DOMContentLoaded', function() {
    initializeDocumentation();
    loadSavedTheme();
    setupNavigation();
    setupSearch();
    setupMobileMenu();
    loadInitialContent();
});

// Initialize documentation functionality
function initializeDocumentation() {
    console.log('Documentation initialized');
    //setupScrollSpy();
    //setupCodeHighlighting();
    //setupTableOfContents();
}

// Theme Management
function toggleTheme() {
    const body = document.body;
    const themeIcon = document.querySelector('.theme-toggle i');
    
    body.classList.toggle('dark-theme');
    
    if (body.classList.contains('dark-theme')) {
        themeIcon.className = 'fas fa-sun';
        localStorage.setItem('theme', 'dark');
    } else {
        themeIcon.className = 'fas fa-moon';
        localStorage.setItem('theme', 'light');
    }
}

function loadSavedTheme() {
    const savedTheme = localStorage.getItem('theme');
    const body = document.body;
    const themeIcon = document.querySelector('.theme-toggle i');
    
    if (savedTheme === 'dark') {
        body.classList.add('dark-theme');
        if (themeIcon) themeIcon.className = 'fas fa-sun';
    }
}

// Mobile Sidebar Toggle
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.querySelector('.sidebar-overlay');
    
    if (sidebar) {
        sidebar.classList.toggle('open');
        
        // Create overlay if it doesn't exist
        if (!overlay) {
            const newOverlay = document.createElement('div');
            newOverlay.className = 'sidebar-overlay';
            document.body.appendChild(newOverlay);
            
            newOverlay.addEventListener('click', () => {
                sidebar.classList.remove('open');
                newOverlay.remove();
            });
        }
    }
}

// Navigation Setup
function setupNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Remove active class from all links
            navLinks.forEach(l => l.classList.remove('active'));
            
            // Add active class to clicked link
            this.classList.add('active');
            
            // Close mobile sidebar
            const sidebar = document.getElementById('sidebar');
            if (sidebar) {
                sidebar.classList.remove('open');
            }
            
            // Get section from href or onclick
            const href = this.getAttribute('href');
            const section = href ? href.substring(1) : this.getAttribute('onclick')?.match(/'([^']+)'/)?.[1];
            
            if (section) {
                loadSection(section);
            }
        });
    });
}

// Search functionality
function setupSearch() {
    const searchInput = document.querySelector('.search-box');
    if (!searchInput) return;
    
    searchInput.addEventListener('input', function() {
        const query = this.value.toLowerCase().trim();
        searchDocs(query);
    });
    
    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        if (e.ctrlKey && e.key === 'k') {
            e.preventDefault();
            searchInput.focus();
            searchInput.select();
        }
    });
}

function searchDocs(query) {
    const navItems = document.querySelectorAll('.nav-item');
    const navSections = document.querySelectorAll('.nav-section');
    
    if (!query) {
        navItems.forEach(item => {
            item.style.display = 'block';
            item.classList.remove('search-match');
        });
        navSections.forEach(section => section.style.display = 'block');
        return;
    }
    
    let hasVisibleItems = false;
    
    navSections.forEach(section => {
        let sectionHasMatches = false;
        const items = section.querySelectorAll('.nav-item');
        
        items.forEach(item => {
            const text = item.textContent.toLowerCase();
            const link = item.querySelector('.nav-link');
            
            if (text.includes(query)) {
                item.style.display = 'block';
                item.classList.add('search-match');
                sectionHasMatches = true;
                hasVisibleItems = true;
                
                // Highlight matching text
                highlightSearchTerm(link, query);
            } else {
                item.style.display = 'none';
                item.classList.remove('search-match');
                clearHighlight(link);
            }
        });
        
        section.style.display = sectionHasMatches ? 'block' : 'none';
    });
    
    // Show no results message
    showSearchNoResults(!hasVisibleItems);
}

function highlightSearchTerm(element, term) {
    const originalText = element.dataset.originalText || element.textContent;
    element.dataset.originalText = originalText;
    
    const regex = new RegExp(`(${term})`, 'gi');
    const highlightedText = originalText.replace(regex, '<mark>$1</mark>');
    
    const textNode = element.childNodes[1] || element.childNodes[0];
    if (textNode && textNode.nodeType === Node.TEXT_NODE) {
        const span = document.createElement('span');
        span.innerHTML = highlightedText;
        textNode.replaceWith(span);
    }
}

function clearHighlight(element) {
    const originalText = element.dataset.originalText;
    if (originalText) {
        const textNode = element.querySelector('span') || element;
        if (textNode && textNode !== element) {
            textNode.textContent = originalText;
        }
    }
}

function showSearchNoResults(show) {
    const existingMessage = document.querySelector('.search-no-results');
    
    if (show) {
        if (!existingMessage) {
            const noResults = document.createElement('div');
            noResults.className = 'search-no-results';
            noResults.innerHTML = `
                <div class="no-results-content">
                    <i class="fas fa-search"></i>
                    <p>No matching documentation found</p>
                </div>
            `;
            document.querySelector('.nav-menu').appendChild(noResults);
        }
    } else {
        if (existingMessage) {
            existingMessage.remove();
        }
    }
}

// Mobile Menu Setup
function setupMobileMenu() {
    const mobileBtn = document.querySelector('.mobile-menu-btn');
    if (mobileBtn) {
        mobileBtn.addEventListener('click', toggleSidebar);
    }
    
    // Close sidebar on window resize
    window.addEventListener('resize', function() {
        if (window.innerWidth > 768) {
            const sidebar = document.getElementById('sidebar');
            if (sidebar) {
                sidebar.classList.remove('open');
            }
        }
    });
}

// Load initial content based on URL parameters
function loadInitialContent() {
    const urlParams = new URLSearchParams(window.location.search);
    const docType = urlParams.get('doc');
    
    if (docType) {
        loadSection(docType);
        
        // Update active navigation
        const activeLink = document.querySelector(`[onclick*="${docType}"]`);
        if (activeLink) {
            document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
            activeLink.classList.add('active');
        }
    } else {
        // Load default content
        loadSection('installation');
    }
}

// Load section content
function loadSection(section) {
    const contentArea = document.getElementById('content-area');
    if (!contentArea) return;
    
    // Add loading state
    contentArea.classList.add('loading');
    
    // Get content based on section
    const content = getContentForSection(section);
    
    // Simulate loading delay for better UX
    setTimeout(() => {
        contentArea.innerHTML = content;
        contentArea.classList.remove('loading');
        contentArea.classList.add('fade-in');
        
        // Re-run code highlighting
        if (typeof Prism !== 'undefined') {
            Prism.highlightAll();
        }
        
        // Update URL
        const newUrl = `${window.location.pathname}?doc=${section}`;
        history.replaceState(null, '', newUrl);
        
        // Scroll to top
        contentArea.scrollIntoView({ behavior: 'smooth' });
        
    }, 300);
}

