
// Theme Toggle
function toggleTheme() {
    document.body.classList.toggle('dark-theme');
    const icon = document.querySelector('.theme-toggle i');
    icon.className = document.body.classList.contains('dark-theme')
        ? 'fas fa-sun'
        : 'fas fa-moon';

    // Save theme preference
    localStorage.setItem('theme', document.body.classList.contains('dark-theme') ? 'dark' : 'light');
}

// Load saved theme
document.addEventListener('DOMContentLoaded', function () {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
        document.body.classList.add('dark-theme');
        document.querySelector('.theme-toggle i').className = 'fas fa-sun';
    }
});

// Mobile Sidebar Toggle
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('open');

    // Close sidebar when clicking outside
    if (sidebar.classList.contains('open')) {
        document.addEventListener('click', function closeSidebar(e) {
            if (!sidebar.contains(e.target) && !e.target.closest('.mobile-menu-btn')) {
                sidebar.classList.remove('open');
                document.removeEventListener('click', closeSidebar);
            }
        });
    }
}

// Navigation
function loadSection(section) {
    // Remove active class from all links
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });

    // Add active class to clicked link
    event.target.classList.add('active');

    // Close mobile sidebar
    document.getElementById('sidebar').classList.remove('open');

    // Load content based on section
    const contentArea = document.getElementById('content-area');
    contentArea.className = 'fade-in';

    // Re-run Prism highlighting
    if (typeof Prism !== 'undefined') {
        Prism.highlightAll();
    }
}

// Search functionality
function searchDocs(query) {
    const navItems = document.querySelectorAll('.nav-item');
    query = query.toLowerCase();

    navItems.forEach(item => {
        const text = item.textContent.toLowerCase();
        item.style.display = text.includes(query) ? 'block' : 'none';
    });
}

// Smooth scrolling for anchor links
document.addEventListener('click', function (e) {
    if (e.target.matches('a[href^="#"]')) {
        e.preventDefault();
        const target = document.querySelector(e.target.getAttribute('href'));
        if (target) {
            target.scrollIntoView({ behavior: 'smooth' });
        }
    }
});

// Auto-hide mobile sidebar on scroll
let lastScrollTop = 0;
window.addEventListener('scroll', function () {
    const sidebar = document.getElementById('sidebar');
    const currentScrollTop = window.pageYOffset || document.documentElement.scrollTop;

    if (currentScrollTop > lastScrollTop && window.innerWidth <= 768) {
        sidebar.classList.remove('open');
    }
    lastScrollTop = currentScrollTop;
});



function loadIframe(page, element = null) {
    document.getElementById('contentFrame').src = page;

    // Remove active class from all links
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });

    // Add active class (only if element exists)
    if (element) {
        element.classList.add('active');
    }

    // Close mobile sidebar
    document.getElementById('sidebar').classList.remove('open');

    // Fade animation
    const contentArea = document.getElementById('content-area');
    if (contentArea) contentArea.className = 'fade-in';

    // Re-run Prism highlighting
    if (typeof Prism !== 'undefined') {
        Prism.highlightAll();
    }
}
