Quick eCommerce  
Version: 1.0  
© 2025 Quick Ecommerce / BizMic Limited  
All rights reserved.  

-------------------------------------------------------  
1. DESCRIPTION  
-------------------------------------------------------  
	Quick Ecommerce is a powerful, multi-vendor and multi-store eCommerce solution.  
	It supports a range of store types — Grocery, Medicine, Bags, Clothing, Furniture, Books, Gadgets, Pets, and more — all from a unified, scalable platform. :contentReference[oaicite:0]{index=0}  

	With user-friendly mobile apps and a high-performance web frontend, Quick Ecommerce empowers admins, sellers, customers, and delivery personnel with tailored experiences. :contentReference[oaicite:1]{index=1}  


2. COMPONENTS / TECHNOLOGY STACK  
-------------------------------------------------------  
	This project includes:  

	Laravel (Backend)  
	  › API endpoints, admin panel, vendor management, commission system, analytics. :contentReference[oaicite:2]{index=2}  
	React + Next.js (Web / Customer Frontend)  
	  › SEO-optimized, dynamic web application for customer storefront. :contentReference[oaicite:3]{index=3}  
	Flutter Apps  
	  › Customer Mobile/Web Apps


3. FEATURES  
-------------------------------------------------------  
	Cross-platform mobile apps (iOS, Android)  
	Customer web app (Flutter) for browsing and checkout  
	React/Next.JS based Admin panel for super admin (vendor management, payments, analytics)  
	React/Next.JS based Vendor dashboard / Store panel for managing products and orders  
	Role-based access control system for different types of users :contentReference[oaicite:5]{index=5}  
	Scalable architecture to support multiple store types  
	Real-time order tracking (for delivery personnel)  


4. REQUIREMENTS  
-------------------------------------------------------  
	Backend (Laravel):  
	  › PHP (8.2+)  
	  › MySQL / MariaDB  
	  › Composer  
	  › Web server (Apache / Nginx)  

	Admin Frontend (Next.JS v16+):  
	  › Node.js
	  › npm / yarn  

	Mobile App (Flutter):  
	  › Flutter SDK  
	  › Android Studio / Xcode for building mobile apps  


5. INSTALLATION / SETUP  
-------------------------------------------------------  
	Backend (Laravel):  
		› Copy `.env.example` to `.env` and configure environment variables (database, API keys, etc.).  
		› Run `composer install`.  
		› Generate application key: `php artisan key:generate`.  
		› Run migrations: `php artisan migrate`.  
		› (Optional) Run seeders: `php artisan db:seed`.  
		› Link storage: `php artisan storage:link`.  
		› Configure CORS or domain as needed.  

	Admin Frontend (React / Next.js):  
		› Go to `frontend-react/` folder.  
		› Copy `.env.example` to `.env.local` and set API URL and other keys.  
		› Run `npm install` (or `yarn install`).  
		› Run development build: `npm run dev`.  
		› For production: `npm run build` and `npm run start` (or follow Next.js production instructions).  

	Flutter App:  
		› Go to `flutter-app/` folder.  
		› Run `flutter pub get`.  
		› For Android: `flutter build apk` (or `flutter run`).  
		› For iOS: `flutter build ios` (or `flutter run`).  
		› For Web: `flutter build web`.  
		› Make sure to configure API endpoints and any Firebase / push-notification settings in your Flutter app.


6. DOCUMENTATION  
-------------------------------------------------------  
	Refer to the `Documentation/` folder for:  
		› Detailed installation guide  
		› API documentation  
		› Server requirements  
		› FAQs  
		› Changelog  


7. LICENSING  
-------------------------------------------------------  
	This is a CodeCanyon / Envato-style project. By using this software, you are bound by Envato’s License Terms.  
	You must not:  
		› Distribute the full source code to others (unless permitted by the license)  
		› Remove any copyright / license information  
		› Use this in a way that violates the Envato license  


8. SUPPORT / CONTACT  
-------------------------------------------------------  
	If you encounter issues or need help:  
		› Check the Documentation folder first  
		› For bugs, feature requests, or questions, contact: bravosoftltd@gmail.com
		› Work Hours: Saturday–Thursday, 9:00 AM – 5:00 PM [GMT+6] (Hotline: +880 1722 31 36 35)


9. CHANGELOG – v1.0  
-------------------------------------------------------  
	Initial release  
	Includes core modules: Laravel backend, Next.js Admin, Flutter mobile apps (customer)  
	Multi-vendor and multi-store capability  
	Role-based access control  
	Real-time order tracking  


10. DISCLAIMER  
-------------------------------------------------------  
	This software is provided “as is”, without warranty of any kind. Use it at your own risk. The developers / authors are not responsible for any data loss or business disruption resulting from the use of this software.


Thank you for using Quick eCommerce — we hope it helps you build and scale your eCommerce business easily!

